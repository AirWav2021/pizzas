import React from 'react'
import { NotFoundBlock } from '../components/NotFound'

export const NotFound = () => {
	return <NotFoundBlock />
}
